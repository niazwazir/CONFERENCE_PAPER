from tensorflow.keras.layers import Conv2D, Input, PReLU, Conv2DTranspose, LeakyReLU, add, concatenate
from tensorflow.keras.initializers import RandomNormal, HeNormal
from tensorflow.keras.models import Model
import tensorflow as tf
from tensorflow.keras.layers import Conv2D, Input, Lambda
from tensorflow.keras.initializers import RandomNormal
from tensorflow.keras.models import Model
import tensorflow as tf

scale=8
#######################SEB BLOCK#####################################
def CSRB_Block(upscale_factor=8, channels=3):
    inputs = Input(shape=(None, None, channels))
    C1 = Conv2D(3,(1,1),padding = 'same',kernel_initializer=HeNormal())(inputs) ##########earlier 25.74 we used 32
    L1 = LeakyReLU(alpha=0.2)(C1)
    C2 = Conv2D(3,(3,3),padding = 'same',kernel_initializer=HeNormal())(inputs)
    L2 = LeakyReLU(alpha=0.2)(C2)
    C3 = Conv2D(3,(5,5),padding = 'same',kernel_initializer=HeNormal())(inputs)
    L3 = LeakyReLU(alpha=0.2)(C3)
    C4 = Conv2D(3,(7,7),padding = 'same',kernel_initializer=HeNormal())(inputs)
    L4 = LeakyReLU(alpha=0.2)(C4)
    C5 = Conv2D(3,(9,9),padding = 'same',kernel_initializer=HeNormal())(inputs)
    L5 = LeakyReLU(alpha=0.2)(C5)
    cat1 = concatenate([L1, L2,L3,L4,L5], axis = -1)
    cat2 = concatenate([L1, L2,L3,L4,L5], axis = -1)
    cat3 = concatenate([L1, L2,L3,L4,L5], axis = -1)
    cat4 = concatenate([L1, L2,L3,L4,L5], axis = -1)
    cat5 = concatenate([L1, L2,L3,L4,L5], axis = -1)
    
    PC5 = Conv2D(3,(3,3),padding='same',kernel_initializer=HeNormal())(cat1)
    DWC5  = Conv2D(3,(1,1),padding='same',kernel_initializer=HeNormal())(PC5)
    
    PC6 = Conv2D(3,(3,3),padding='same',kernel_initializer=HeNormal())(cat2)
    DWC6  = Conv2D(3,(1,1),padding='same',kernel_initializer=HeNormal())(PC6)
    
    PC7 = Conv2D(3,(3,3),padding='same',kernel_initializer=HeNormal())(cat3)
    DWC7  = Conv2D(3,(1,1),padding='same',kernel_initializer=HeNormal())(PC7)
    
    PC8 = Conv2D(3,(3,3),padding='same',kernel_initializer=HeNormal())(cat4)
    DWC8  = Conv2D(3,(1,1),padding='same',kernel_initializer=HeNormal())(PC8)
    
    PC9 = Conv2D(3,(3,3),padding='same',kernel_initializer=HeNormal())(cat5)
    DWC9  = Conv2D(3,(1,1),padding='same',kernel_initializer=HeNormal())(PC9)
    
    
    Sum2  = add([inputs,DWC5,DWC6,DWC7,DWC8,DWC9])
    PPC2 = LeakyReLU(alpha=0.2)(Sum2)
    model = Model(inputs= inputs, outputs=PPC2)
    return model
######################MCSNet ARCHITECTURE#####################################
def MCSNet(scale):
    X_in = Input(shape=(None, None, 3))
    C11 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(X_in)
    LA = LeakyReLU(alpha=0.2)(C11)
    C22 = Conv2D(3,3, padding='same',kernel_initializer=HeNormal())(LA)
    SEB1 = CSRB_Block()(C22)
    sum2  = add([X_in,SEB1])
    C1 = Conv2D(3,3, padding='same', kernel_initializer=HeNormal())(sum2)
    SEB2 = CSRB_Block()(C1)
    sum3  = add([X_in,SEB2])
    C2 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum3)
    SEB3 = CSRB_Block()(C2)
    sum4  = add([X_in,SEB3])
    C3 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum4)
    SEB4 = CSRB_Block()(C3)
    sum5  = add([X_in,SEB4])
    C4 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum5)
    SEB5 = CSRB_Block()(C4)
    sum6  = add([X_in,SEB5])
    C5 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum6)
    #SEB6 = CSRB_Block()(C5)
    #sum7  = add([X_in,SEB6])
    #C6 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum7)
    #SEB7 = CSRB_Block()(C6)
    #sum8  = add([X_in,SEB7])
    #C7 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum8)
    #SEB8 = CSRB_Block()(C7)
    #sum9  = add([X_in,SEB8])
    #C8 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum9)
    #SEB9 = CSRB_Block()(C8)
    #sum10  = add([X_in,SEB9])
    #C9 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(sum10)
    #SEB10 = CSRB_Block()(C9)
    #C10 = Conv2D(3, 3, padding='same',kernel_initializer=HeNormal())(SEB10)
    T = Conv2DTranspose(3, 9, strides=scale, padding='same',kernel_initializer=RandomNormal(mean=0.0, stddev=0.001))(C5)
    X_out = tf.clip_by_value(T, 0.0, 1.0)
    return Model(X_in, X_out)

model = MCSNet(scale=8)
model.summary()

